
// api/scrape.js - Vercel API Route for Reddit Scraping

export default async function handler(req, res) {
    if (req.method !== "POST") {
        return res.status(405).json({ error: "Method Not Allowed" });
    }

    const { keyword } = req.body;
    if (!keyword) {
        return res.status(400).json({ error: "Keyword is required" });
    }

    const CRAWL4AI_API_KEY = process.env.CRAWL4AI_API_KEY;
    const GROQ_API_KEY = process.env.GROQ_API_KEY;

    try {
        // Crawl Reddit using Crawl4AI
        const crawlResponse = await fetch("https://api.crawl4ai.com/crawl", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${CRAWL4AI_API_KEY}`
            },
            body: JSON.stringify({
                url: `https://www.reddit.com/search/?q=${encodeURIComponent(keyword)}`,
                depth: 2,
                maxResults: 20
            })
        });
        const crawlData = await crawlResponse.json();
        const redditPosts = crawlData.results.map(post => ({
            title: post.title,
            url: post.url,
            content: post.text
        }));

        // Summarize with Groq
        const groqResponse = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${GROQ_API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-4",
                messages: [{
                    role: "system",
                    content: `Analyze the following Reddit discussions about '${keyword}' and summarize key insights.`
                }, {
                    role: "user",
                    content: redditPosts.map(p => `${p.title}: ${p.content}`).join("\n\n")
                }]
            })
        });
        const groqData = await groqResponse.json();
        const summary = groqData.choices[0].message.content;

        res.status(200).json({ redditPosts, summary });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}
