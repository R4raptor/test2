document.getElementById("searchButton").addEventListener("click", async () => {
    const keyword = document.getElementById("searchInput").value;
    if (!keyword) {
        alert("Please enter a keyword");
        return;
    }

    document.getElementById("results").innerHTML = "Loading...";

    const response = await fetch("/api/scrape", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keyword })
    });

    const data = await response.json();
    if (data.error) {
        document.getElementById("results").innerHTML = "Error: " + data.error;
        return;
    }

    let html = "<h2>Results:</h2>";
    data.redditPosts.forEach(post => {
        html += `<h3><a href="${post.url}" target="_blank">${post.title}</a></h3><p>${post.content}</p>`;
    });

    html += `<h2>Summary:</h2><p>${data.summary}</p>`;
    document.getElementById("results").innerHTML = html;
});
